import torch
from torchvision import datasets, transforms
from torchvision.datasets import ImageFolder
from torch.utils.data import DataLoader


def get_dataset(args):
    DATA_ROOT = '../'+args.name + '/data/'
    mean, std = get_mean_std(args, DATA_ROOT)
    if args.model_name == 'VGG':
        transform = transforms.Compose([
            transforms.Resize((args.image_size, args.image_size)),
            transforms.ToTensor(),
            transforms.Normalize(mean=mean, std=std)
        ])
    else:
        transform = transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(args.image_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=mean, std=std)
        ])

    full_dataset = ImageFolder(root=DATA_ROOT, transform=transform)
    return full_dataset

def get_mean_std(args, DATA_ROOT):
    if args.model_name == 'VGG':
        transform = transforms.Compose([
        transforms.Resize((args.image_size, args.image_size)),
        transforms.ToTensor(),
    ])
    else:
        transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(args.image_size),
        transforms.ToTensor(),
    ])
    dataset = ImageFolder(root=DATA_ROOT, transform=transform)
    loader = DataLoader(dataset, batch_size=args.batch_size, num_workers=args.num_workers)

    mean = 0.0
    std = 0.0
    nb_samples = 0.0
    for images, _ in loader:
        batch_samples = images.size(0)
        images = images.view(batch_samples, images.size(1),-1)
        mean += images.mean(2).sum(0)
        std += images.std(2).sum(0)
        nb_samples += batch_samples

    mean /= nb_samples
    std /= nb_samples

    return mean.tolist(), std.tolist()