import torch
import argparse
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader, Subset, Dataset
import torch.nn as nn
import torch.optim as optim
import torchvision.models as models
import pandas as pd

from datasets import get_dataset

def record_result(val_loader, model_object_or_path, args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    if isinstance(model_object_or_path, str):
        if args.model_name == 'VGG':
            model = models.vgg16()
            model.classifier[6] = nn.Linear(model.classifier[6].in_features, 2)
        elif args.model_name == 'ResNet':
            model = models.resnet50()
            num_ftrs = model.fc.in_features
            model.fc = nn.Linear(num_ftrs, 2)
        elif args.models_name == 'AlexNet':
            model = models.alexnet()
            model.classifier[6] = nn.Linear(model.classifier[6].in_features, 2)
        else:
            print("Please enter VGG, ResNet or AlexNet")
            exit()
        try:
            model.load_state_dict(torch.load(model_object_or_path, map_location=device))
        except Exception as e:
            print("Failed to load the model.")
            return [], [], []
    elif isinstance(model_object_or_path, nn.Module):
        model = model_object_or_path
    else:
        raise ValueError("Failed to load the model.")

    model = model.to(device)
    model.eval()
    
    fold_true_labels = []
    fold_pred_classes = []
    fold_pred_probs_positive_class = []

    with torch.no_grad():
        for images, labels in val_loader:
            images = images.to(device)
            labels = labels.to(device)

            outputs = model(images)
            probabilities = torch.softmax(outputs, dim=1) 
            _, predicted_classes_batch = torch.max(outputs.data, 1)

            fold_true_labels.extend(labels.cpu().numpy())
            fold_pred_classes.extend(predicted_classes_batch.cpu().numpy())
            fold_pred_probs_positive_class.extend(probabilities[:, 1].cpu().numpy())

    return fold_true_labels, fold_pred_classes, fold_pred_probs_positive_class

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', type=str, default='Superlets')
    parser.add_argument('--model_name', type=str, default='VGG')
    parser.add_argument('--image_size', type=int, default=224)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--num_fold', type=int, default=10)
    parser.add_argument('--num_workers', type=int, default=2)
    parser.add_argument('--lr', type=float, default=1e-5)
    parser.add_argument('--wd', type=float, default=0.01)
    parser.add_argument('--epoch', type=int, default=130)

    args = parser.parse_args()
    
    print(f"strat: {args.name}")
    full_dataset = get_dataset(args)

    if not hasattr(full_dataset, 'targets') or not hasattr(full_dataset, 'imgs'):
        print("error")
        exit()

    all_targets_original = np.array(full_dataset.targets)
    class_counts = np.bincount(all_targets_original)

    if len(class_counts) < 2:
        balanced_indices = np.arange(len(all_targets_original))
        if not balanced_indices.any():
            print("error")
            exit()
    else:
        minority_class = np.argmin(class_counts)
        majority_class = np.argmax(class_counts)
        if minority_class == majority_class:
            balanced_indices = np.arange(len(all_targets_original))
        else:
            print(f"Minority Class: {minority_class} (Counts: {class_counts[minority_class]})")
            print(f"Majority Class: {majority_class} (Counts: {class_counts[majority_class]})")

            minority_indices_list = [i for i, path_label_tuple in enumerate(full_dataset.imgs) if path_label_tuple[1] == minority_class]
            majority_indices_list = [i for i, path_label_tuple in enumerate(full_dataset.imgs) if path_label_tuple[1] == majority_class]
            
            if not minority_indices_list:
                 print(f"Error: Minority Class {minority_class} has no samples.")
                 exit()
            if not majority_indices_list:
                 print(f"Error: Majority Class {majority_class} has no samples.")
                 exit()

            np.random.seed(42)
            undersampled_majority_indices = np.random.choice(
                majority_indices_list, size=len(minority_indices_list), replace=False
            )
            balanced_indices_list = minority_indices_list + undersampled_majority_indices.tolist()
            balanced_indices = np.array(balanced_indices_list)
            print(f"After downsampling, the number of samples for each category is: {len(minority_indices_list)}")

    balanced_targets = all_targets_original[balanced_indices]
    print(f"The total number of samples in the balanced dataset: {len(balanced_indices)}")
    if len(balanced_indices) < args.num_fold:
        print(f"Error: After balancing, the number of samples in sampple ({args.num_fold}) is less than the number of cross-validation folds.")
        exit()

    skf = StratifiedKFold(n_splits=args.num_fold, shuffle=True, random_state=42)
    
    fold_accuracies = []
    fold_aucs = []
    fold_best_data_for_excel = {}

    tprs_list_for_mean_roc = []
    mean_fpr_base = np.linspace(0, 1, 100)
    
    all_cv_true_labels = np.array(balanced_targets)
    all_cv_pred_probs = np.empty_like(all_cv_true_labels, dtype=float)

    fig_roc, ax_roc = plt.subplots(figsize=(12, 10))

    for fold, (train_fold_idx_in_balanced, val_fold_idx_in_balanced) in enumerate(skf.split(balanced_indices, balanced_targets)):
        fold_num = fold + 1
        print(f"\nfold {fold_num}/{args.num_fold} -----")

        train_actual_indices_in_full = balanced_indices[train_fold_idx_in_balanced]
        val_actual_indices_in_full = balanced_indices[val_fold_idx_in_balanced]

        train_subset = Subset(full_dataset, train_actual_indices_in_full)
        val_subset = Subset(full_dataset, val_actual_indices_in_full)

        train_loader = DataLoader(train_subset, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True)
        val_loader = DataLoader(val_subset, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)

        if args.model_name == 'VGG':
            model = models.vgg16()
            model.classifier[6] = nn.Linear(model.classifier[6].in_features, 2)
        elif args.model_name == 'ResNet':
            model = models.resnet50()
            num_ftrs = model.fc.in_features
            model.fc = nn.Linear(num_ftrs, 2)
        elif args.models_name == 'AlexNet':
            model = models.alexnet()
            model.classifier[6] = nn.Linear(model.classifier[6].in_features, 2)
        else:
            print("Please enter VGG, ResNet or AlexNet")
            exit()
        
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        model = model.to(device)
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.wd)
        
        best_val_acc_this_fold = 0.0
        model_save_path_this_fold = f'../autodl-tmp/best_model_fold_{fold_num}_{args.name}_{args.model_name}.pth'

        print(f"fold {fold_num}, epoch {args.epoch}")
        for epoch_num_this_fold in range(args.epoch):
            model.train()
            running_loss_train = 0.0
            correct_preds_train = 0
            total_samples_train = 0
            for images, labels in train_loader:
                images, labels = images.to(device), labels.to(device)
                optimizer.zero_grad()
                outputs = model(images)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()
                running_loss_train += loss.item() * images.size(0)
                _, predicted = torch.max(outputs.data, 1)
                total_samples_train += labels.size(0)
                correct_preds_train += (predicted == labels).sum().item()
            
            epoch_loss_train = running_loss_train / total_samples_train if total_samples_train > 0 else 0
            epoch_acc_train = correct_preds_train / total_samples_train if total_samples_train > 0 else 0

            model.eval()
            running_loss_val = 0.0
            correct_preds_val = 0
            total_samples_val = 0
            with torch.no_grad():
                for images, labels in val_loader:
                    images, labels = images.to(device), labels.to(device)
                    outputs = model(images)
                    loss = criterion(outputs, labels)
                    running_loss_val += loss.item() * images.size(0)
                    _, predicted = torch.max(outputs.data, 1)
                    total_samples_val += labels.size(0)
                    correct_preds_val += (predicted == labels).sum().item()
            
            epoch_loss_val = running_loss_val / total_samples_val if total_samples_val > 0 else 0
            epoch_acc_val = correct_preds_val / total_samples_val if total_samples_val > 0 else 0

            print(f"  fold {epoch_num_this_fold+1}/{args.epoch} - "
                  f"train_loss: {epoch_loss_train:.4f}, train_acc: {epoch_acc_train:.4f} | "
                  f"val_loss: {epoch_loss_val:.4f}, val_acc: {epoch_acc_val:.4f}")
            
            if epoch_acc_val > best_val_acc_this_fold:
                best_val_acc_this_fold = epoch_acc_val
                torch.save(model.state_dict(), model_save_path_this_fold)


        if args.model_name == 'VGG':
            model = models.vgg16()
            model.classifier[6] = nn.Linear(model.classifier[6].in_features, 2)
        elif args.model_name == 'ResNet':
            model = models.resnet50()
            num_ftrs = model.fc.in_features
            model.fc = nn.Linear(num_ftrs, 2)
        elif args.models_name == 'AlexNet':
            model = models.alexnet()
            model.classifier[6] = nn.Linear(model.classifier[6].in_features, 2)
        else:
            print("Please enter VGG, ResNet or AlexNet")
            exit()
        best_model_this_fold.load_state_dict(torch.load(model_save_path_this_fold))
        best_model_this_fold = best_model_this_fold.to(device)

        true_labels_val_fold, pred_classes_val_fold, pred_probs_val_fold = record_result(val_loader, best_model_this_fold)

        fold_best_data_for_excel[f'Fold{fold_num}_true'] = true_labels_val_fold
        fold_best_data_for_excel[f'Fold{fold_num}_pred_classes'] = pred_classes_val_fold

        fpr_fold, tpr_fold, _ = roc_curve(true_labels_val_fold, pred_probs_val_fold)
        roc_auc_this_fold = auc(fpr_fold, tpr_fold)
        
        fold_accuracies.append(best_val_acc_this_fold)
        fold_aucs.append(roc_auc_this_fold)

        interp_tpr_fold = np.interp(mean_fpr_base, fpr_fold, tpr_fold)
        interp_tpr_fold[0] = 0.0
        tprs_list_for_mean_roc.append(interp_tpr_fold)

        ax_roc.plot(fpr_fold, tpr_fold, lw=1.5, alpha=0.4, label=f'ROC Fold {fold_num} (AUC = {roc_auc_this_fold:.3f})')
        
        all_cv_pred_probs[val_fold_idx_in_balanced] = np.array(pred_probs_val_fold)

        print(f"fold {fold_num} finish - best_val_acc: {best_val_acc_this_fold:.4f}, val_AUC: {roc_auc_this_fold:.4f}")


    print("\n----- Result -----")
    if fold_accuracies and fold_aucs:
        for i in range(len(fold_accuracies)):
            print(f'fold {i+1}: acc = {fold_accuracies[i]:.4f}, AUC = {fold_aucs[i]:.4f}')
        
        mean_accuracy_cv = np.mean(fold_accuracies)
        std_accuracy_cv = np.std(fold_accuracies)
        mean_auc_cv = np.mean(fold_aucs)
        std_auc_cv = np.std(fold_aucs)

        print(f'\nmean_acc: {mean_accuracy_cv:.4f} (± {std_accuracy_cv:.3f})')
        print(f'mean_auc: {mean_auc_cv:.4f} (± {std_auc_cv:.3f})')

        ax_roc.plot([0, 1], [0, 1], linestyle='--', lw=2, color='grey', label='Random Guess Line (AUC = 0.50)', alpha=.8)
        
        if tprs_list_for_mean_roc:
            mean_tpr_cv = np.mean(tprs_list_for_mean_roc, axis=0)
            mean_tpr_cv[-1] = 1.0
            ax_roc.plot(mean_fpr_base, mean_tpr_cv, color='blue',
                    label=f'mean ROC (mean AUC = {mean_auc_cv:.3f} $\pm$ {std_auc_cv:.3f})',
                    lw=2.5, alpha=.8)

            std_tpr_cv = np.std(tprs_list_for_mean_roc, axis=0)
            tprs_upper = np.minimum(mean_tpr_cv + std_tpr_cv, 1)
            tprs_lower = np.maximum(mean_tpr_cv - std_tpr_cv, 0)
            ax_roc.fill_between(mean_fpr_base, tprs_lower, tprs_upper, color='cornflowerblue', alpha=.3,
                            label=r'$\pm$ 1 Standard Deviation (TPR)')
    else:
        print("Data deficiencies")


    if np.any(all_cv_pred_probs == np.empty_like(all_cv_true_labels, dtype=float)[0]):
        print("The out-of-sample prediction probabilities for some sample are missing")

    fpr_overall_cv, tpr_overall_cv, _ = roc_curve(all_cv_true_labels, all_cv_pred_probs)
    auc_overall_cv = auc(fpr_overall_cv, tpr_overall_cv)
    ax_roc.plot(fpr_overall_cv, tpr_overall_cv, color='darkorange', linestyle=':',
             label=f'Overall Cross-Validated ROC (AUC = {auc_overall_cv:.3f})',
             lw=3, alpha=.9)
    
    ax_roc.set_xlim([-0.05, 1.05])
    ax_roc.set_ylim([-0.05, 1.05])
    ax_roc.set_xlabel('False Positive Rate', fontsize=15)
    ax_roc.set_ylabel('True Positive Rate', fontsize=15)
    ax_roc.set_title(f'Cross-validated ROC curve - {args.name}+{args.model_name}', fontsize=16)
    ax_roc.legend(loc="lower right", fontsize=9)
    ax_roc.grid(True, linestyle='--', alpha=0.6)
    
    roc_plot_filename = f'./{args.model_name}_{args.name}_ROC_curves_combined.png'
    try:
        fig_roc.savefig(roc_plot_filename)
        print(f'The ROC curves has been save to: {roc_plot_filename}')
    except Exception as e:
        print(f"error: {e}")
    plt.show()

    if fold_best_data_for_excel:
        max_len_excel = 0
        for key_excel in fold_best_data_for_excel:
            max_len_excel = max(max_len_excel, len(fold_best_data_for_excel[key_excel]))
        
        df_data_to_save_excel = {}
        for fold_num_excel_save in range(args.num_fold):
            fold_num_actual = fold_num_excel_save + 1
            true_key_excel = f'Fold{fold_num_actual}_true'
            pred_key_excel = f'Fold{fold_num_actual}_pred_classes'
            true_list = list(fold_best_data_for_excel[true_key_excel])
            pred_list = list(fold_best_data_for_excel[pred_key_excel])
            df_data_to_save_excel[true_key_excel] = true_list + [None]*(max_len_excel - len(true_list))
            df_data_to_save_excel[pred_key_excel] = pred_list + [None]*(max_len_excel - len(pred_list))

        result_df_excel = pd.DataFrame(df_data_to_save_excel)
        excel_filename = f'./{args.models}_{args.name}_CV_fold_predictions.xlsx'
        result_df_excel.to_excel(excel_filename, index=False)
    else:
        print("Data does not exist")